Só funciona na ens5, ens3 da segfault na linha 107.
