#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

double wtime();
